#include <condition_variable>
#include "DvsenseDriver/camera/FusionCamera.hpp"
#include "DvsenseDriver/camera/DvsCameraManager.hpp"
#include <opencv2/opencv.hpp>
#include "DvsenseBase/logging/logger.hh"
#include "DvsenseDriver/DataProcess/DvsApsFusionProccessor.hpp"
#include "DvsenseDriver/Calibration/Calibrator.hpp"
#include "DvsenseBase/Utils/Json/JsonUtils.hpp"
#include <thread>
#include <chrono>
class SyncDisplayer
{
public:
	dvsense::TimeStamp aps_frame_export_start_time_ = 0;
	dvsense::TimeStamp aps_frame_export_end_time_ = 0;
	std::mutex aps_frame_buffer_mutex_;

	cv::Mat fusion_image_;
	cv::Mat fusion_image_swap_;
	std::mutex fusion_image_mutex_;

	cv::Mat fusion_image_dvs_size_;
	cv::Mat fusion_image_dvs_size_swap_;
	std::mutex fusion_image_dvs_size_mutex_;

	cv::Mat aps_raw_image_;
	cv::Mat aps_raw_image_swap_;
	std::mutex aps_raw_image_mutex_;

	cv::Mat dvs_raw_image_;
	cv::Mat dvs_raw_image_swap_;
	std::mutex dvs_raw_image_mutex_;

	std::mutex event_buffer_mutex_;
	using EventBuffer = std::vector<uint16_t>;
	std::unique_ptr<EventBuffer> event_buffer_;
	int max_count_ = 10;

	int dvs_height_ = 720;
	int dvs_width_ = 1280;

	int aps_height_ = 2160;
	int aps_width_ = 3840;

	// Gray
	cv::Vec3b color_bg_ = cv::Vec3b(0xff, 0xff, 0xff);
	cv::Vec3b color_on_ = cv::Vec3b(0xff, 0x00, 0x00);
	cv::Vec3b color_off_ = cv::Vec3b(0x00, 0x00, 0xff);

    // Performance statistics
	double process_aps_time_ = 0.0;
	double fusion_dvs_time_ = 0.0;
	double total_callback_time_ = 0.0;
	long callback_count_ = 0;
	std::mutex stats_mutex_;

	SyncDisplayer(int dvs_height, int dvs_width) : dvs_height_(dvs_height), dvs_width_(dvs_width)
	{
		aps_raw_image_ = cv::Mat(aps_height_, aps_width_, CV_8UC3);
		aps_raw_image_swap_ = cv::Mat(aps_height_, aps_width_, CV_8UC3);

		fusion_image_dvs_size_ = cv::Mat(dvs_height_, dvs_width_, CV_8UC3);
		fusion_image_dvs_size_swap_ = cv::Mat(dvs_height_, dvs_width_, CV_8UC3);

		event_buffer_ = std::make_unique<EventBuffer>(dvs_height_ * dvs_width_ * 2, 0);
	}

	void getFusionImage(cv::Mat &display)
	{
		// Swap images
		{
			std::unique_lock<std::mutex> lock(fusion_image_dvs_size_mutex_);
			std::swap(fusion_image_dvs_size_, fusion_image_dvs_size_swap_);
			fusion_image_dvs_size_.setTo(color_bg_);
		}
		fusion_image_dvs_size_swap_.copyTo(display);
	}

	void getApsImage(cv::Mat &display)
	{
		// Swap images
		{
			std::unique_lock<std::mutex> lock(aps_raw_image_mutex_);
			std::swap(aps_raw_image_, aps_raw_image_swap_);
		}
		aps_raw_image_swap_.copyTo(display);
	}

	void processApsFrame(dvsense::ApsFrame &aps_frame)
	{
		std::unique_lock<std::mutex> lock(aps_raw_image_mutex_);
		std::memcpy(fusion_image_dvs_size_.data, aps_frame.data(), aps_frame.getDataSize());
		aps_frame_export_end_time_ = aps_frame.exposure_end_timestamp;
	}

	void fusionDvsToAps(const dvsense::Event2D *begin, const dvsense::Event2D *end)
	{
		std::unique_lock<std::mutex> lock(fusion_image_dvs_size_mutex_);
		for (auto event = begin; event != end; ++event)
		{
			if (event->y >= dvs_height_ || event->x >= dvs_width_)
			{
				continue;
			}

			fusion_image_dvs_size_.at<cv::Vec3b>(event->y, event->x) = (event->polarity) ? color_on_ * 0.3 + fusion_image_dvs_size_.at<cv::Vec3b>(event->y, event->x) * 0.7
																						 : color_off_ * 0.3 + fusion_image_dvs_size_.at<cv::Vec3b>(event->y, event->x) * 0.7;
		}
	}

	void updateEvents(const dvsense::Event2D *begin, const dvsense::Event2D *end)
	{
		int index = 0;
		std::unique_lock<std::mutex> lock(event_buffer_mutex_);
		for (auto &event = begin; event != end; event++)
		{
			int y = event->y;
			int x = event->x;

			index = (y * dvs_width_ + x) * 2 + event->polarity;
			if (index >= event_buffer_->size())
			{
				continue;
			}
			if (event_buffer_->at(index) < max_count_)
			{
				event_buffer_->at(index)++;
			}
		}
	}

	void visualizeEventsOnAPS(cv::Mat &canvas)
	{
		std::unique_lock<std::mutex> lock(fusion_image_mutex_);
		cv::resize(canvas, fusion_image_, cv::Size(aps_width_, aps_height_));
		for (int y = 0; y < dvs_height_; y++)
		{
			for (int x = 0; x < dvs_width_; x++)
			{
				int base_idx = (y * dvs_width_ + x) * 2;
				int negative_event_cnt = event_buffer_->at(base_idx);
				int positive_event_cnt = event_buffer_->at(base_idx + 1);
				int y_rectified = int(float(y - 360) * 4.86 / 1.45) + 1080;
				int x_rectified = int(float(x - 640) * 4.86 / 1.45) + 1920;
				if (y_rectified < 0 || x_rectified < 0)
					continue;
				if (y_rectified >= aps_height_ || x_rectified >= aps_width_)
					continue;
				if (positive_event_cnt > 0 && positive_event_cnt >= negative_event_cnt)
				{
					fusion_image_.at<cv::Vec3b>(y_rectified, x_rectified) =
						cv::Vec3b(0, 0, uint8_t(255.0 * (positive_event_cnt - negative_event_cnt) / max_count_));
				}
				else if (negative_event_cnt > 0 && negative_event_cnt > positive_event_cnt)
				{
					fusion_image_.at<cv::Vec3b>(y_rectified, x_rectified) =
						cv::Vec3b(uint8_t(255.0 * (negative_event_cnt - positive_event_cnt) / max_count_), 0, 0);
				}
			}
		}
	}

	void mapAPSToDvsSize(const cv::Mat &aps_raw_image, cv::Mat &fusion_image, int aps_width, int aps_height, int dvs_width, int dvs_height)
	{
		// 确保输入图像是三通道的BGR格式
		if (aps_raw_image.empty() || aps_raw_image.channels() != 3)
		{
			throw std::invalid_argument("Input aps_raw_image must be a non-empty 3-channel BGR image.");
		}

		// 如果fusion_image为空或者尺寸不匹配，则创建或调整大小
		if (fusion_image.empty() || fusion_image.size() != cv::Size(dvs_width, dvs_height))
		{
			fusion_image = cv::Mat(dvs_height, dvs_width, aps_raw_image.type());
		}

		for (int y_target = 0; y_target < dvs_height; ++y_target)
		{
			for (int x_target = 0; x_target < dvs_width; ++x_target)
			{
				int y_aps = static_cast<int>((static_cast<float>(y_target - dvs_height / 2) * 4.86 / 1.45) + aps_height / 2);
				int x_aps = static_cast<int>((static_cast<float>(x_target - dvs_width / 2) * 4.86 / 1.45) + aps_width / 2);
				
				if (y_aps >= 0 && y_aps < aps_raw_image.rows &&
					x_aps >= 0 && x_aps < aps_raw_image.cols)
				{

					fusion_image.at<cv::Vec3b>(y_target, x_target) = aps_raw_image.at<cv::Vec3b>(y_aps, x_aps);
				}
				else
				{
					// 设置背景颜色，需要确保color_bg_是一个有效的cv::Scalar类型变量
					fusion_image.at<cv::Vec3b>(y_target, x_target) = color_bg_;
				}
			}
		}
	}
};

int main(int argc, char *argv[])
{
	// ----------------- Program description -----------------

	const std::string short_program_desc(
		"Simple viewer to stream events from device, using the SDK driver API.\n");
	std::string long_program_desc(short_program_desc +
								  "Press 'q' or Escape key to leave the program.\n"
								  "Press 'Space' key to start/stop recording events to a raw file.\n");

	if (argc > 1 && (std::string(argv[1]) == "-h" || std::string(argv[1]) == "--help"))
	{
		std::cout << "Usage: " << argv[0] << " [output_file_path]" << std::endl;
		std::cout << "Default output file path: ./\n Default output file name: default_file_name" << std::endl
				  << std::endl;
		std::cout << long_program_desc << std::endl;
		return 0;
	}

	std::string out_file_path = ".";
	std::string out_file_name = "default_file_name";
	if (argc == 3 && std::string(argv[1]) != "-h" && std::string(argv[1]) != "--help")
	{
		out_file_path = argv[1];
		out_file_name = argv[2];
	}
	else
	{
		std::cout << "The current file path is not entered, "
				  << "and the default file name is used to save the file. "
				  << "If you need to set the file name,"
				  << "use the input parameters to set it." << std::endl
				  << std::endl;
	}

	std::cout << long_program_desc << std::endl;


	// ----------------- Camera initialization -----------------
	dvsense::FusionCameraDevice camera = nullptr;
	bool is_recording = false;
	bool stop_application = false;
	dvsense::DsStatisticInfo statistic_info;
	dvsense::DvsApsFusionProccessor fusion_processor;
	dvsense::Calibrator calibrator;
	do
	{
		if (!camera || !camera->isConnected())
		{
			camera.reset();
			// find all cameras
			dvsense::DvsCameraManager cameraManager;
			std::vector<dvsense::CameraDescription> cameraDescs = cameraManager.getCameraDescs();
			if (cameraDescs.size() == 0)
			{
				LOG_INFO("Watting camera connect...");
				std::this_thread::sleep_for(std::chrono::milliseconds(1000));
				continue;
			}
			std::string open_camera_serial;
			// Print all cameras found
			for (auto &cameraDesc : cameraDescs)
			{
				std::cout << "Camera found: " << cameraDesc.manufacturer << ": " << cameraDesc.serial << std::endl;
				if(cameraDesc.product == "DVSync" )
				{
					open_camera_serial = cameraDesc.serial;
				}
			}
			if(open_camera_serial.empty())
			{
				LOG_ERROR("No DVSync camera found, please connect a DVSync camera.");
				std::this_thread::sleep_for(std::chrono::milliseconds(1000));
				continue;
			}
			// Open the first camera found
			camera = cameraManager.openFusionCamera(open_camera_serial);
			dvsense::CalibratorParameters cali_param;
			if(camera->readCalibrationParam(cali_param))
			{
				dvsense::paramToJsonFile(cali_param, "./calibration.json");
				calibrator.loadCalibrationParam(cali_param);
			}
			
			// fusion_processor.addFusionDataCallback([&sync_displayer, &calibrator](dvsense::ApsFrame &frame, const dvsense::Event2D *begin, const dvsense::Event2D *end)
			// 									   { 
			// 										auto start_total = std::chrono::high_resolution_clock::now();
													
			// 										auto start_process = std::chrono::high_resolution_clock::now();
			// 										dvsense::ApsFrame aps_to_dvs_frame = calibrator.mapApsToDvs(frame);
			// 										sync_displayer.processApsFrame(aps_to_dvs_frame);
			// 										auto end_process = std::chrono::high_resolution_clock::now();
													
			// 										auto start_fusion = std::chrono::high_resolution_clock::now();
			// 										sync_displayer.fusionDvsToAps(begin, end); 
			// 										auto end_fusion = std::chrono::high_resolution_clock::now();
													
			// 										auto end_total = std::chrono::high_resolution_clock::now();
													
			// 										auto process_duration = std::chrono::duration_cast<std::chrono::microseconds>(end_process - start_process);
			// 										auto fusion_duration = std::chrono::duration_cast<std::chrono::microseconds>(end_fusion - start_fusion);
			// 										auto total_duration = std::chrono::duration_cast<std::chrono::microseconds>(end_total - start_total);
													
			// 										// Update statistics
			// 										{
			// 											std::lock_guard<std::mutex> lock(sync_displayer.stats_mutex_);
			// 											sync_displayer.process_aps_time_ = process_duration.count() / 1000.0; // Convert to milliseconds
			// 											sync_displayer.fusion_dvs_time_ = fusion_duration.count() / 1000.0;
			// 											sync_displayer.total_callback_time_ = total_duration.count() / 1000.0;
			// 											LOG_INFO("process_aps_time_, : %f, fusion_dvs_time_ : %f, total_callback_time_ : %f", 
			// 											sync_displayer.process_aps_time_, sync_displayer.fusion_dvs_time_, sync_displayer.total_callback_time_);
			// 											sync_displayer.callback_count_++;
			// 										}
			// 									});

			camera->addApsFrameCallback([&fusion_processor](const dvsense::ApsFrame frame)
										{ fusion_processor.addApsData(frame); });
			camera->addEventsStreamHandleCallback([&fusion_processor](const dvsense::Event2D *begin, const dvsense::Event2D *end)
												  { fusion_processor.addDvsData(begin, end); });
			camera->addSyncSignalCallback([&fusion_processor](const dvsense::EventTriggerIn &trigger_in)
										 { fusion_processor.addSyncSignal(trigger_in); });
			camera->setStatisticInfoCallback([&statistic_info](const dvsense::DsStatisticInfo info)
											 { statistic_info = info; });



			camera->start();
		}

		// If user presses `q` key, exit loop and stop application
		std::string input_command;
		std::getline(std::cin, input_command);
		
		if (input_command == "q" || input_command == "quit")
		{
			stop_application = true;
			
			camera->stop();
			std::cout << "Quit command received, exiting." << std::endl;
		}
		else if (input_command == "r" || input_command == " ")
		{
			if (is_recording)
			{
				is_recording = false;
				camera->stopRecording();
				std::cout << "Stop saving raw file: " << out_file_path << std::endl;
			}
			else
			{
				is_recording = true;
				if (camera->startRecording(out_file_path, out_file_name) == 0)
				{
					std::cout << "Start saving raw file: " << out_file_path << std::endl;
				}
			}
			if (!stop_application) {
				std::cout << "Please enter command ('q' to quit, ' ' to record): ";
			}
		}
		else if (!input_command.empty()) 
		{
			std::cout << "Unknown command. Please enter 'q' to quit or ' ' to record: ";
		}
	} while (!stop_application);
	return 0;
}
