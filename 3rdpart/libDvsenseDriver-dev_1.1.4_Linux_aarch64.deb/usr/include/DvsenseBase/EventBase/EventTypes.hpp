#ifndef __EVENT_TYPES_HPP__
#define __EVENT_TYPES_HPP__

#include <cstddef>
#include <cstdint>
#include <vector>
#include <functional>
#include "DvsenseBase/Utils/TypeUtils.hpp"
#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32
namespace dvsense
{
    class EventBase
    {
    };

    class DVSENSE_API Event2D : public EventBase
    {
    public:
        Event2D(
            uint16_t x,
            uint16_t y,
            uint8_t polarity,
            TimeStamp timestamp) : x(x), y(y), timestamp(timestamp), polarity(polarity) {}
        Event2D() : x(0), y(0), timestamp(0), polarity(0) {}
        uint16_t x;
        uint16_t y;
        /// @brief 0: decrease, 1: increase
        uint8_t polarity;
        /// @brief timestamp in microseconds
        TimeStamp timestamp;
    };

    class DVSENSE_API EventTriggerIn : public EventBase
    {
    public:
        EventTriggerIn(
            short id,
            short polarity,
            TimeStamp timestamp) : id(id), polarity(polarity), timestamp(timestamp) {}
        EventTriggerIn() : id(0), polarity(0), timestamp(0) {}
        short polarity;
        TimeStamp timestamp;
        short id;
    };

    class DVSENSE_API DsStatisticInfo : public EventBase
    {
    public:
        DsStatisticInfo(
            uint64_t bandwidth_byte,
            uint64_t events_count) : bandwidth_byte(bandwidth_byte), events_count(events_count) {}
        DsStatisticInfo() : bandwidth_byte(0), events_count(0){}
        uint64_t bandwidth_byte;
        uint64_t events_count;
    };

    using Event2DVector = std::vector<Event2D>;
    using EventIterator_t = Event2D*;
    using EventsStreamHandleCallback = std::function<void(EventIterator_t begin, EventIterator_t end)>;
    using DvsTriggerInCallback = std::function<void(const EventTriggerIn)>;
    using DsStatisticInfoCallback = std::function<void(const DsStatisticInfo)>; 
} // namespace dvsense

#endif // __EVENT_TYPES_HPP__
