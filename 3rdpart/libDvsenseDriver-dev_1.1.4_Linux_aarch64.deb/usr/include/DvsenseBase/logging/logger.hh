#ifndef __DVSENSE_LOGGER_HPP__
#define __DVSENSE_LOGGER_HPP__

#include <sstream>
#include <memory>
#include <cstdarg>

#ifdef _WIN32

#ifdef DVSENSE_BASE_EXPORTS
#define DVSENSE_BASE_API __declspec(dllexport)
#else
#define DVSENSE_BASE_API __declspec(dllimport)
#endif
#else
#define DVSENSE_BASE_API
#endif // _WIN32

// Macro definitions for ease of use
#define LOGGER dvsense::Logger::Instance()
#define LOG_TRACE(...) dvsense::Logger::Instance().log_(dvsense::LogLevelType::TRACE, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_DEBUG(...) dvsense::Logger::Instance().log_(dvsense::LogLevelType::DEBUG, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_INFO(...) dvsense::Logger::Instance().log_(dvsense::LogLevelType::INFO, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_WARN(...) dvsense::Logger::Instance().log_(dvsense::LogLevelType::WARN, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_ERROR(...) dvsense::Logger::Instance().log_(dvsense::LogLevelType::ERR, __FILE__, __LINE__, __VA_ARGS__)
#define LOG_FATAL(...) dvsense::Logger::Instance().log_(dvsense::LogLevelType::FATAL, __FILE__, __LINE__, __VA_ARGS__)

namespace dvsense
{

    enum class DVSENSE_BASE_API LogLevelType
    {
        TRACE = 0,
        DEBUG = 1,
        INFO = 2,
        WARN = 3,
        ERR = 4,
        FATAL = 5
    };

    class DVSENSE_BASE_API Logger
    {
    public:
        Logger(const Logger &) = delete;
        Logger &operator=(const Logger &) = delete;
        ~Logger();
        void setLogLevel(LogLevelType level);
        LogLevelType getLogLevel() { return level_; }

        // Static method to get the singleton instance
        static Logger &Instance()
        { 
            static Logger instance;
            return instance;
        }

        void log_(LogLevelType level, const char *file, int line, const char *fmt, ...);

    private:
        class Impl;
        std::unique_ptr<Impl> impl_;
        LogLevelType level_;
        Logger();
        // std::string getFileName(const std::string& filePath);
    };

} // namespace dvsense

#endif // __DVSENSE_LOGGER_HPP__
