#ifndef __TYPE_UTILS_HPP__
#define __TYPE_UTILS_HPP__

#include <cstdint>
#include <string>
#include <map>
#include "DvsenseBase/Utils/Json/nlohmann/json.hpp"
namespace dvsense
{
	typedef uint64_t TimeStamp;
	struct DvsFileInfo
	{
		TimeStamp start_timestamp; // Start timestamp of the raw file
		TimeStamp end_timestamp;   // End timestamp of the raw file
		TimeStamp aps_start_timestamp;   // End timestamp of the raw file
		uint64_t max_events;        // Maximum number of events in the raw file
		uint16_t dvs_width;
		uint16_t dvs_height;
		std::string serial_number;
	};

	using json = nlohmann::json;
	using ordered_json = nlohmann::ordered_json;

	struct MatrixData
	{
		int rows;
		int cols;
		int type;
		std::vector<double> data;
	};

	struct CalibratorParameters
	{
		std::string camera_serial;
		uint16_t dvs_cols;
		uint16_t dvs_rows;
		uint16_t aps_cols;
		uint16_t aps_rows;

		MatrixData camera_matrix;
		MatrixData dist_coeffs;

		std::map<std::string, MatrixData> affine_matrix;

		std::vector<double> rotation;
		std::vector<double> translation;
	};

} // namespace dvsense

#endif
