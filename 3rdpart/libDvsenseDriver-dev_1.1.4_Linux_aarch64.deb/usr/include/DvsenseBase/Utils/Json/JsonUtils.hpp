#ifndef __DVSENSE_JSON_UTILS_HPP__
#define __DVSENSE_JSON_UTILS_HPP__
#include <fstream>
#include <vector>
#include "DvsenseBase/Utils/TypeUtils.hpp"
#include "DvsenseBase/Utils/Json/nlohmann/json.hpp"
#include "DvsenseBase/logging/logger.hh"
#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense
{
    bool DVSENSE_API jsonDataToParam(std::vector<uint8_t> &data, CalibratorParameters &param);

    bool DVSENSE_API jsonFileToParam(std::string json_file, CalibratorParameters &param);

    bool DVSENSE_API paramToJsonFile(CalibratorParameters &param, std::string json_file);
}
#endif // __DVSENSE_JSON_UTILS_HPP__