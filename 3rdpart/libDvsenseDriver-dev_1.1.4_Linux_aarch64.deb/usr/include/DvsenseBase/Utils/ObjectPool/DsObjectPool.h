#ifndef DVSENSE_OBJECT_POOL_H
#define DVSENSE_OBJECT_POOL_H
#include <memory>

#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense
{
    class DVSENSE_API DsObjectPoolBase
    {
    public:
        virtual ~DsObjectPoolBase() = default;
        virtual bool empty() const = 0;
        virtual size_t size() const = 0;
    };

    template <typename T>
    class DVSENSE_API DsObjectPool : public DsObjectPoolBase
    {
    public:
        using ptr_type = std::shared_ptr<T>;
        virtual ptr_type acquire() = 0;
        virtual ~DsObjectPool() = default;
    };

}

#endif // DVSENSE_OBJECT_POOL_H