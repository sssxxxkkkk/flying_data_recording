#ifndef DVSENSE_OBJECT_POOL_FACTORY_H
#define DVSENSE_OBJECT_POOL_FACTORY_H
#include <memory>
#include "DvsenseBase/EventBase/EventTypes.hpp"
#include "DvsenseBase/Utils/ObjectPool/DsObjectPool.h"

#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense
{
    class DVSENSE_API DsObjectPoolFactory
    {
    public:
        template <typename T>
        static std::unique_ptr<DsObjectPool<T>> createUniqueDsObjectPool(size_t size = 64);

        template <typename T>
        static std::unique_ptr<DsObjectPool<T>> createUniqueDsObjectPoolWithArgs(size_t size, int vector_size);
    };
}
#endif // DVSENSE_OBJECT_POOL_FACTORY_H