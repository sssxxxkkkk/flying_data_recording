#ifndef __FUNC_UTILS_HPP__
#define __FUNC_UTILS_HPP__

#include <vector>
#include <stdint.h>
#include <string>
#include "DvsenseBase/Utils/TypeUtils.hpp"
#ifdef _WIN32
#include <windows.h>
#include <setupapi.h>
#include <cfgmgr32.h>
#include <devguid.h>
#pragma comment(lib, "setupapi.lib")
#pragma comment(lib, "cfgmgr32.lib")
#endif

#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense
{
    inline void swap16(uint8_t *data)
    {
        // 直接交换两个字节
        uint8_t temp = data[0];
        data[0] = data[1];
        data[1] = temp;
    }

    void DVSENSE_API convertEndian(std::vector<uint8_t> &buffer);

    std::string DVSENSE_API hexToString(int number, int n_digits);

    std::string DVSENSE_API intToString(int number, int n_digits);

    std::string DVSENSE_API getSysTime();

    std::string DVSENSE_API generateDvsFileHeader(DvsFileInfo& file_info);

#ifdef _WIN32
    std::string DVSENSE_API utf8ToLocal8Bit(const std::string &utf8);

    std::string DVSENSE_API local8bitToUtf8(const std::string &localStr);
#endif

    bool DVSENSE_API restartUSBDevice(uint16_t vid, uint16_t pid);
}

#endif
