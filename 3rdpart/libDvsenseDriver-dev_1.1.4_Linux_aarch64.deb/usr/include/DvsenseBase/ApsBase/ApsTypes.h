#ifndef __APS_TYPES_HPP__
#define __APS_TYPES_HPP__

#include <cstddef>
#include <cstdint>
#include <vector>
#include <functional>
#include <memory>
#include <vector>
#include "DvsenseBase/Utils/TypeUtils.hpp"
#include "DvsenseBase/EventBase/EventTypes.hpp"

#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32
namespace dvsense
{
    enum class ApsPixelType
    {
        BGR888,
    };

    class DVSENSE_API ApsFrame
    {
    public:
        ApsFrame(int width = 3840, int height = 2160, TimeStamp start_ts = 0, TimeStamp end_ts = 0);

        ApsFrame(int width, int height, TimeStamp start_ts, TimeStamp end_ts,
                 uint8_t *external_data, size_t data_size,
                 bool own_data = false);

        ApsFrame(const ApsFrame &other);

        ApsFrame &operator=(const ApsFrame &other);

        ApsFrame clone() const;

        uint8_t *data();

        const uint8_t *data() const;

        size_t getDataSize() const;

        int width() const;

        int height() const;

        ApsPixelType pixelType() const;

        TimeStamp exposure_start_timestamp;
        TimeStamp exposure_end_timestamp;

    private:
        int width_;
        int height_;
        ApsPixelType pixel_type_;
        std::shared_ptr<uint8_t[]> data_;
    };

    using FrameCallback = std::function<void(ApsFrame)>;
    using DsFusionDataCallback = std::function<void(ApsFrame &, EventIterator_t begin, EventIterator_t end)>;
} // namespace dvsense

#endif // __EVENT_TYPES_HPP__
