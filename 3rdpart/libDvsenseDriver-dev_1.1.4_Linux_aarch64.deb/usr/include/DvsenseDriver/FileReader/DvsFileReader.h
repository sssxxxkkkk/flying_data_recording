#ifndef DVS_FILE_READER_H
#define DVS_FILE_READER_H

#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32

#include <memory>
#include "DvsenseHal/camera/DvsCameraUtils.hpp"
#include "DvsenseBase/EventBase/EventTypes.hpp"
#include "DvsenseBase/Utils/TypeUtils.hpp"

namespace dvsense
{
    /** \~english @brief DVS File Reader class
     * \~chinese @brief DVS 文件读取器类
     */
    class DVSENSE_API DvsFileReader
    {
    public:
        /** \~english @brief Default constructor
         * \~chinese @brief 默认构造函数
         */
        DvsFileReader() {};

        /** \~english @brief Virtual destructor
         * \~chinese @brief 虚析构函数
         */
        virtual ~DvsFileReader() { };

        /** \~english @brief Create a File Reader object
         * \~english @param filepath Path to the file
         * \~english @return std::unique_ptr<DvsFileReader> Unique pointer to the created file reader
         * \~chinese @brief 创建一个文件读取器对象
         * \~chinese @param filepath 文件路径
         * \~chinese @return std::unique_ptr<DvsFileReader> 创建的文件读取器的唯一指针
         */
        static std::unique_ptr<DvsFileReader> createFileReader(std::string filepath);

        /** \~english @brief Loads a RAW file for event processing.
         * \~english @param filepath The full path of the RAW file to be loaded.
         * \~english @return True if the file was successfully loaded, false otherwise.
         * \~english @note This function might take significant time to complete depending on the file size.
         * \~chinese @brief 加载RAW文件以处理事件。
         * \~chinese @param filepath 要加载的RAW文件的完整路径。
         * \~chinese @return 如果文件加载成功，则返回true，否则返回false。
         * \~chinese @note 根据文件大小，此函数可能需要较长的时间来完成。
         */
        virtual bool loadFile() = 0;

        /** \~english @brief Get the Seek start of TimeStamp in the file
         * \~english @param start_timestamp Reference to the start timestamp.
         * \~english @return True if the file has timestamp information, true is returned.
         * \~english @return False if there is no timestamp information in the file, false is returned.
         * \~chinese @brief 获取文件中时间戳的起始位置。
         * \~chinese @param start_timestamp 时间戳起始位置的引用。
         * \~chinese @return 如果文件中有时间戳信息，则返回true。
         * \~chinese @return 如果文件中没有时间戳信息，则返回false。
         */
        virtual bool getStartTimeStamp(TimeStamp& start_timestamp) = 0;

        /** \~english @brief Get the Seek end of TimeStamp in the file
         * \~english @param end_timestamp Reference to the end timestamp.
         * \~english @return True if the file has timestamp information, true is returned.
         * \~english @return False if there is no timestamp information in the file, false is returned.
         * \~chinese @brief 获取文件中时间戳的结束位置。
         * \~chinese @param end_timestamp 时间戳结束位置的引用。
         * \~chinese @return 如果文件中有时间戳信息，则返回true。
         * \~chinese @return 如果文件中没有时间戳信息，则返回false。
         */
        virtual bool getEndTimeStamp(TimeStamp& end_timestamp) = 0;

        /** \~english @brief Get the maximum number of events available.
         * \~english @param num Reference to store the maximum number of events.
         * \~english @return True if the maximum event count is successfully retrieved.
         * \~english @return False if the event count cannot be determined.
         * \~chinese @brief 获取可用的最大事件数量。
         * \~chinese @param num 引用参数，用于存储最大事件数量。
         * \~chinese @return 如果成功获取最大事件数量，则返回 true。
         * \~chinese @return 如果无法确定事件数量，则返回 false。
         */
        virtual bool getMaxEvents(uint64_t &num) = 0;

        /** \~english @brief Check if the end of the event data has been reached.
         * \~english @return True if all events have been read and no more data is available.
         * \~english @return False if there are still unread events.
         * \~chinese @brief 检查是否已经到达事件数据的末尾。
         * \~chinese @return 如果所有事件都已读取且没有更多数据，则返回 true。
         * \~chinese @return 如果仍然有未读取的事件，则返回 false。
         */
        virtual bool reachedEndOfEvents() = 0;


        /** \~english @brief Seeks to a specific timestamp in the file.
         * 
         * This function moves the current position in the file to the event at the specified timestamp. If the
         * provided timestamp is out of bounds, the current position will be set to the start or end of the file
         * accordingly.
         * 
         * \~english @param t The target timestamp to seek to.
         * \~english @return True if the seek operation was successful, false if the timestamp was not found.
         * \~chinese @brief 寻找文件中的特定时间戳。
         * 
         * 此函数将文件当前位置移动到指定时间戳的事件。如果提供的时间戳超出范围，则当前位置将设置为文件开始或结束位置。
         * 
         * \~chinese @param t 要寻找的目标时间戳。
         * \~chinese @return 如果寻址操作成功，则返回true，如果未找到时间戳，则返回false。
         */
        virtual bool seekTime(TimeStamp t) = 0;

        /** \~english @brief Seeks to the n event in the file.
        * \~english @param t The target event num to seek to.
        * \~english @return True if the seek operation was successful, false if the n event was not found.
        * \~chinese @brief 寻找文件中的第n个事件。
        * 
        * 此函数将文件当前位置移动到指定索引的事件。如果提供的事件索引超出范围，则当前位置将设置为文件开始或结束位置。
        * 
        * \~chinese @param t 要寻找的n。
        * \~chinese @return 如果寻址操作成功，则返回true，如果未找到事件，则返回false。
        */
        virtual bool seekNEvents(uint64_t n_event) = 0;

        /** \~english @brief Gets the timestamp of the current file decode location
         * \~english @return TimeStamp 
         * \~english @note When reading a fixed number of events or at a fixed time interval,
         * the timestamp of the current file location may not correspond to the timestamp of the returned event.
         * \~chinese @brief 获取当前文件解码位置的时间戳。
         * \~chinese @return TimeStamp 
         * \~chinese @note 当以固定数量的事件或固定时间间隔读取时，
         * 当前文件位置的时间戳可能与返回的事件的时间戳不对应。
         */
        virtual TimeStamp getCurrentPosTimeStamp() = 0;

        /** \~english @brief Gets the number of events from the start of the file to the current file decoding location
         * \~english @return events num 
         * \~chinese @brief 获取从文件开头到当前文件解码位置的事件数量。
         * \~chinese @return 事件数量
         */
        virtual uint64_t getCurrentPosEventNum() = 0;

        /** \~english @brief Retrieves a specified number of events from the current file position.
         * \~english @param n The number of events to retrieve.
         * \~english @return A shared pointer to an Event2DVector containing the retrieved events.
         * \~english @warning This function is not thread-safe and the buffer will be overwritten on the next call.
         * \~chinese @brief 从当前位置检索指定数量的事件。
         * \~chinese @param n 要检索的事件数量。
         * \~chinese @return 包含检索到的事件的 Event2DVector 的共享指针。
         * \~chinese @warning 此函数不是线程安全的，并且缓冲区将在下次调用时被覆盖。
         */
        virtual std::shared_ptr<Event2DVector> getNEvents(uint64_t n) = 0;

        /** \~english @brief Retrieves a specified number of events starting from a given timestamp.
         * \~english @param start The timestamp to start reading from.
         * \~english @param n The number of events to retrieve.
         * \~english @return A shared pointer to an Event2DVector containing the retrieved events.
         * \~english @warning This function is not thread-safe and the buffer will be overwritten on the next call.
         * \~chinese @brief 从给定的时间戳开始检索指定数量的事件。
         * \~chinese @param start 开始读取的时间戳。
         * \~chinese @param n 要检索的事件数量。
         * \~chinese @return 包含检索到的事件的 Event2DVector 的共享指针。
         * \~chinese @warning 此函数不是线程安全的，并且缓冲区将在下次调用时被覆盖。
         */
        virtual std::shared_ptr<Event2DVector> getNEventsGivenStartTimeStamp(TimeStamp start, uint64_t n) = 0;

        /** \~english @brief Retrieves a specific number of events from a specified location.
         * \~english @param event_num The event number to start reading from.
         * \~english @param n The number of events which to retrieve.
         * \~english @return A shared pointer to an Event2DVector containing the retrieved events.
         * \~english @warning This function is not thread-safe and the buffer will be overwritten on the next call.
         * \~chinese @brief 从指定位置检索特定数量的事件。
         * \~chinese @param event_num 开始读取的事件位置。
         * \~chinese @param n 要检索事件的数量。
         * \~chinese @return 包含检索到的事件的 Event2DVector 的共享指针。
         * \~chinese @warning 此函数不是线程安全的，并且缓冲区将在下次调用时被覆盖。
         */
        virtual std::shared_ptr<Event2DVector> getNEventsGivenStartEvent(uint64_t event_num, uint64_t n) = 0;

        /** \~english @brief Retrieves events within a specific time interval from the current position.
         * \~english @param interval The time interval during which to retrieve events.
         * \~english @return A shared pointer to an Event2DVector containing the retrieved events.
         * \~english @warning This function is not thread-safe and the buffer will be overwritten on the next call.
         * \~chinese @brief 从当前位置检索特定时间间隔内的事件。
         * \~chinese @param interval 要检索事件的时间间隔。
         * \~chinese @return 包含检索到的事件的 Event2DVector 的共享指针。
         * \~chinese @warning 此函数不是线程安全的，并且缓冲区将在下次调用时被覆盖。
         */
        virtual std::shared_ptr<std::vector<Event2D>> getNTimeEvents(TimeStamp interval) = 0;

        /** \~english @brief Retrieves events within a specific time interval from the current position.
        * \~english @param start The timestamp to start reading from.
        * \~english @param interval The time interval during which to retrieve events.
        * \~english @return A shared pointer to an Event2DVector containing the retrieved events.
        * \~english @warning This function is not thread-safe and the buffer will be overwritten on the next call.
        * \~chinese @brief 从当前位置检索特定时间间隔内的事件。
        * \~chinese @param start 开始读取的时间戳。
        * \~chinese @param interval 要检索事件的时间间隔。
        * \~chinese @return 包含检索到的事件的 Event2DVector 的共享指针。
        * \~chinese @warning 此函数不是线程安全的，并且缓冲区将在下次调用时被覆盖。
        */
        virtual std::shared_ptr<Event2DVector> getNTimeEventsGivenStartTimeStamp(TimeStamp start, TimeStamp interval) = 0;

        /** \~english @brief Retrieves events within a specified time interval starting with event num.
         * \~english @param event_num The event num to start reading from.
         * \~english @param interval The time interval during which to retrieve events.
         * \~english @return A shared pointer to an Event2DVector containing the retrieved events.
         * \~english @warning This function is not thread-safe and the buffer will be overwritten on the next call.
         * \~chinese @brief 从第 event_num 个事件开始检索特定时间间隔内的事件。
         * \~chinese @param event_num 开始读取的事件位置。
         * \~chinese @param interval 要检索事件的时间间隔。
         * \~chinese @return 包含检索到的事件的 Event2DVector 的共享指针。
         * \~chinese @warning 此函数不是线程安全的，并且缓冲区将在下次调用时被覆盖。
         */
        virtual std::shared_ptr<std::vector<Event2D>> getNTimeEventsGivenStartEvent(uint64_t event_num, TimeStamp interval) = 0;

        /** \~english @brief Extracts event data within a specified time range and saves the results to a specified output file.
        * \~english @param start The start timestamp.
        * \~english @param end The end timestamp
        * \~english @return Return true if file output succeeds, false otherwise.
        * \~english @warning out_file_path The complete file path must be output, and the file directory must exist.
        * \~english @note It should be noted that the saved file data is not an accurate start timestamp, 
        * and there is a deviation of about 10us from the actual start timestamp.
        * \~chinese @brief 提取指定时间范围内的事件数据，并将结果保存到指定的输出文件中。
        * \~chinese @param start 起始时间戳，表示事件提取的开始时间。
        * \~chinese @param end 结束时间戳，表示事件提取的结束时间。
        * \~chinese @param out_file_path 输出文件的路径，提取的事件数据将被写入此文件
        * \~chinese @return bool 文件输出成功返回true， 反之则返回false
        * \~chinese @warning out_file_path 需要输出完整的文件路径，且文件目录需要存在。
        * \~chinese @note 需要注意的是，保存的文件数据并不是准确的起始时间戳，与实际提取的事件数据时间戳存在10us左右的偏差。
        */
        virtual bool extractEventData(TimeStamp start, TimeStamp end, std::string out_file_path) = 0;

        virtual bool exportEventDataToVideo(TimeStamp start, TimeStamp end, std::string out_file_path) = 0;

        /**
         * \~english @brief Add a callback function to handle events
         * \~english @param cb callback function
         * \~english @return callback id With id you can @ref removeEventsStreamHandleCallback
         * \~chinese @brief 添加一个回调函数来处理事件
         * \~chinese @param cb 回调函数
         * \~chinese @return 回调函数的id，通过id可以@ref removeEventsStreamHandleCallback
         */
        virtual uint32_t addTriggerInCallback(DvsTriggerInCallback cb) = 0;

        /**
         * \~english @brief Remove a callback function by id
         * \~english @param callback_id
         * \~english @return true if removed successfully
         * \~english @return false if there is no callback function with the corresponding id in the callback function list.
         * \~chinese @brief 通过id移除一个回调函数
         * \~chinese @param callback_id 回调函数的id
         * \~chinese @return 如果成功移除返回true
         * \~chinese @return 如果回调函数列表中没有对应id的回调函数，则返回false。
         */
        virtual bool removeTriggerInCallback(uint32_t callback_id) = 0;

        /**
         * \~english @brief Get the width of the sensor used to capture the events
         * \~english @return uint16_t 
         * \~chinese @brief 获取用于捕获事件的传感器的宽度
         * \~chinese @return uint16_t 
         */
        virtual uint16_t getWidth() const = 0;

        /**
         * \~english @brief Get the height of the sensor used to capture the events
         * \~english @return uint16_t 
         * \~chinese @brief 获取用于捕获事件的传感器的高度
         * \~chinese @return uint16_t 
         */
        virtual uint16_t getHeight() const = 0;

        /**
         * \~english @brief Obtain the information of the imported file
         * \~english @return bool 
         * \~chinese @brief 获取导入的文件信息
         * \~chinese @return bool 
         */
        virtual bool getFileInfo(DvsFileInfo& file_info) { return false;};
    };

    /**
     * \~english @brief unique_ptr to manage DVS file reader
     * \~chinese @brief 用于管理DVS文件读取器的unique_ptr
     */
    typedef DVSENSE_API std::unique_ptr<DvsFileReader> DvsFile;

} // namespace dvsense

#endif //DVS_FILE_READER_H