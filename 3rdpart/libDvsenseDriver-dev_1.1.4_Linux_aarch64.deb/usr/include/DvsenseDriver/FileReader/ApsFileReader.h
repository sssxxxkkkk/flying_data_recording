#ifndef DVS_APS_FILE_READER_H
#define DVS_APS_FILE_READER_H

#include "DvsenseBase/Utils/TypeUtils.hpp"
#include "DvsenseBase/ApsBase/ApsTypes.h"
#include "DvsenseBase/logging/logger.hh"

#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense
{
    class DVSENSE_API ApsFileReader
    {

    public:
        ApsFileReader(const std::string filepath){};

        ~ApsFileReader(){};
        
        /** \~english @brief Create a File Reader object
         * \~english @param filepath Path to the file
         * \~english @return std::unique_ptr<DvsFileReader> Unique pointer to the created file reader
         * \~chinese @brief 创建一个文件读取器对象
         * \~chinese @param filepath 文件路径
         * \~chinese @return std::unique_ptr<DvsFileReader> 创建的文件读取器的唯一指针
         */
        static std::unique_ptr<ApsFileReader> createFileReader(std::string filepath);

        /** \~english @brief Load the file
         * \~english @return bool True if the file is loaded successfully, false otherwise
         * \~chinese @brief 加载文件
         * \~chinese @return bool 如果文件加载成功则返回true，否则返回false
         */
        virtual bool loadFile() = 0;

        /** \~english @brief Seek to a specific time stamp
         * \~english @param target_ts Time stamp to seek to
         * \~english @return bool True if the time stamp is found, false otherwise
         * \~chinese @brief 跳转到指定时间戳
         * \~chinese @param target_ts 要跳转的时间戳
         * \~chinese @return bool 如果找到时间戳则返回true，否则返回false
        */
        virtual bool seekTime(TimeStamp target_ts) = 0;

        /** \~english @brief Get all frame time stamps in the file
         * \~english @param timestamps Vector to store the time stamps
         * \~english @return bool True if the time stamps are retrieved successfully, false otherwise
         * \~chinese @brief 获取文件中所有帧的时间戳
         * \~chinese @param timestamps 用于存储时间戳的向量
         * \~chinese @return bool 如果成功获取时间戳则返回true，否则返回false
        */
        virtual bool getTimeStamps(std::vector<TimeStamp>& timestamps) = 0;

        /** \~english @brief Get the next frame in the file
         * \~english @param frame ApsFrame object to store the frame data
         * \~english @return bool True if the frame is retrieved successfully, false otherwise
         * \~chinese @brief 获取文件中的下一帧
         * \~chinese @param frame 用于存储帧数据的ApsFrame对象
         * \~chinese @return bool 如果成功获取帧则返回true，否则返回false
        */
        virtual bool getNextFrame(ApsFrame& frame) = 0;

        /** \~english @brief Get N frames in the file
         * \~english @param n Number of frames to get
         * \~english @param frame ApsFrame object to store the frame data
         * \~english @return bool True if the frames are retrieved successfully, false otherwise
         * \~chinese @brief 获取文件中的N帧
         * \~chinese @param n 要获取的帧数
         * \~chinese @param frame 用于存储帧数据的ApsFrame对象
         * \~chinese @return bool 如果成功获取帧则返回true，否则返回false
        */
        virtual bool getNFrame(int n, ApsFrame& frame) = 0;

        /** \~english @brief Get a frame given a specific time stamp
         * \~english @param target_ts Time stamp of the frame to get
         * \~english @param frame ApsFrame object to store the frame data
         * \~english @return bool True if the frame is retrieved successfully, false otherwise
         * \~chinese @brief 获取指定时间戳的帧
         * \~chinese @param target_ts 要获取的帧的时间戳
         * \~chinese @param frame 用于存储帧数据的ApsFrame对象
         * \~chinese @return bool 如果成功获取帧则返回true，否则返回false
        */
        virtual bool getFrameGivenTimeStamp(TimeStamp target_ts, ApsFrame& frame) = 0;

        /**
         * \~english @brief Get the width of the APS frame
         * \~chinese @brief 获取APS帧的宽度
         */
        uint16_t getWidth(){return aps_width_;};

        /**
         * \~english @brief Get the height of the APS frame
         * \~chinese @brief 获取APS帧的高度
         */
        uint16_t getHeight(){return aps_height_;};

    protected:
        uint16_t aps_width_ = 3840;
        uint16_t aps_height_ = 2160;
    };

} // namespace dvsense

#endif //DVS_RAW_FILE_READER_H
