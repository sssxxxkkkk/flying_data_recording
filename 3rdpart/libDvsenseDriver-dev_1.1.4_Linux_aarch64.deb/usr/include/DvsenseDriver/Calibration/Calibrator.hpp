#ifndef __DVSENSE_CALIBRATOR_HPP__
#define __DVSENSE_CALIBRATOR_HPP__

#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32
#include <string>
#include <atomic>
#include "DvsenseBase/EventBase/EventTypes.hpp"
#include "DvsenseBase/Utils/Json/nlohmann/json.hpp"
#include "DvsenseBase/EventBase/EventTypes.hpp"
#include "DvsenseBase/ApsBase/ApsTypes.h"
#include "DvsenseBase/Utils/TypeUtils.hpp"
#include "DvsenseBase/Utils/Json/JsonUtils.hpp"

#ifdef _WIN32
#define DVSENSE_API __declspec(dllexport)
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense {

class DVSENSE_API Calibrator
{
public:
    Calibrator()
    {
        // Load default param
        param_.dvs_cols = 1280;
        param_.dvs_rows = 720;
        param_.aps_cols = 3840;
        param_.aps_rows = 2160;
        static const double pixel_size_ratio = 4.86 / 1.45; // DVS pixel size ratio to APS
        dvs_to_aps_affine_matrix_ = {pixel_size_ratio, 0, (-param_.dvs_cols / 2) * pixel_size_ratio + param_.aps_cols / 2,
                                     0, pixel_size_ratio, (-param_.dvs_rows / 2) * pixel_size_ratio + param_.aps_rows / 2};
        aps_to_dvs_affine_matrix_ = {1 / pixel_size_ratio, 0, (-param_.aps_cols / 2) * (1 / pixel_size_ratio) + param_.dvs_cols / 2,
                                     0, 1 / pixel_size_ratio, (-param_.aps_rows / 2) * (1 / pixel_size_ratio) + param_.dvs_rows / 2};
    }

    bool loadCalibrationParam(CalibratorParameters &param)
    {
        param_ = param;
        dvs_to_aps_affine_matrix_ = param.affine_matrix["1"].data;
        aps_to_dvs_affine_matrix_ = param.affine_matrix["0"].data;
        offset_x_ = 0.0;
        offset_y_ = 0.0;
        return true;
    }

    void mapDvsToAps(EventIterator_t begin, EventIterator_t end)
    {
        for(auto &ev = begin; ev != end; ++ev)
        {
            // Apply affine transformation to map DVS events to APS frame
            int x = static_cast<int>(ev->x * dvs_to_aps_affine_matrix_[0] + ev->y * dvs_to_aps_affine_matrix_[1] + dvs_to_aps_affine_matrix_[2]);
            int y = static_cast<int>(ev->x * dvs_to_aps_affine_matrix_[3] + ev->y * dvs_to_aps_affine_matrix_[4] + dvs_to_aps_affine_matrix_[5]);
            ev->x = x;
            ev->y = y;
        }
    }

    ApsFrame mapApsToDvs(ApsFrame &src_frame)
    {
        ApsFrame dst_frame(param_.dvs_cols, param_.dvs_rows, src_frame.exposure_start_timestamp, src_frame.exposure_end_timestamp);
        for(int y = 0; y < param_.dvs_rows; ++y)
        {
            for(int x = 0; x < param_.dvs_cols; ++x)
            {
                // Apply affine transformation to map APS pixels to DVS events
                int aps_x = static_cast<int>(x * dvs_to_aps_affine_matrix_[0] + y * dvs_to_aps_affine_matrix_[1] + dvs_to_aps_affine_matrix_[2] + offset_x_);
                int aps_y = static_cast<int>(x * dvs_to_aps_affine_matrix_[3] + y * dvs_to_aps_affine_matrix_[4] + dvs_to_aps_affine_matrix_[5] + offset_y_);
                if (aps_x < 0 || aps_x >= param_.aps_cols || aps_y < 0 || aps_y >= param_.aps_rows)
                {
                    continue;
                }
                int dst_pixel_index = y * param_.dvs_cols + x;
                int src_pixel_index = aps_y * param_.aps_cols + aps_x;
                dst_frame.data()[dst_pixel_index * 3] = src_frame.data()[src_pixel_index * 3];
                dst_frame.data()[dst_pixel_index * 3 + 1] = src_frame.data()[src_pixel_index * 3 + 1];
                dst_frame.data()[dst_pixel_index * 3 + 2] = src_frame.data()[src_pixel_index * 3 + 2];
            }
        }
        return dst_frame;
    }

    void adjustAffineTranslation(double dx, double dy)
    {
        offset_x_ = dx;
        offset_y_ = dy;
    }

    void saveCalibrationParam(std::string &file_path)
    { 
        dvs_to_aps_affine_matrix_[2] += offset_x_;
        dvs_to_aps_affine_matrix_[5] += offset_y_;
        param_.affine_matrix["1"].data = dvs_to_aps_affine_matrix_;
        computeInverseAffine(dvs_to_aps_affine_matrix_.data(), aps_to_dvs_affine_matrix_.data());
        param_.affine_matrix["0"].data = aps_to_dvs_affine_matrix_;
        paramToJsonFile(param_, file_path);
        offset_x_ = 0;
        offset_y_ = 0;
    }

    void computeInverseAffine(const double src[6], double dst[6])
    {
        double a = src[0], b = src[1], tx = src[2];
        double c = src[3], d = src[4], ty = src[5];

        double det = a * d - b * c;
        if (fabs(det) < 1e-12)
        {
            return;
        }

        double inv_det = 1.0 / det;

        double a_ = d * inv_det;
        double b_ = -b * inv_det;
        double c_ = -c * inv_det;
        double d_ = a * inv_det;

        double tx_ = -(a_ * tx + b_ * ty);
        double ty_ = -(c_ * tx + d_ * ty);

        dst[0] = a_;
        dst[1] = b_;
        dst[2] = tx_;
        dst[3] = c_;
        dst[4] = d_;
        dst[5] = ty_;
    }

private:
    CalibratorParameters param_;
    std::vector<double> dvs_to_aps_affine_matrix_;
    std::vector<double> aps_to_dvs_affine_matrix_;
    std::atomic<double> offset_x_ = 0.0;
    std::atomic<double> offset_y_ = 0.0;
};

}

#endif // __DVSENSE_ALGORITHMS_CALIBRATOR_HPP__