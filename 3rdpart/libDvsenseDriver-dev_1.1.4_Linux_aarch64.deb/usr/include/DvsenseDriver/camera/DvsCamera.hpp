#ifndef DVSCAMERA_HPP
#define DVSCAMERA_HPP

#include "DvsenseBase/EventBase/EventTypes.hpp"
#include "DvsenseHal/camera/DvsCameraUtils.hpp"
#include "DvsenseHal/EventStream/RawEventStreamFormat.hpp"
#include "DvsenseHal/camera/tools/CameraTool.h"

#ifdef _WIN32
#ifdef DVSENSE_EXPORTS
    #define DVSENSE_API __declspec(dllexport)
    #else
    #define DVSENSE_API __declspec(dllimport)
    #endif
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense
{

    class DvsCameraManager;

    /**
     * \~english @brief Camera status, STOPPED or STARTED
     * \~chinese @brief 相机状态，STOPPED 或 STARTED
     */
    #ifdef _WIN32
    enum DVSENSE_API CameraStatus
    #else
    enum CameraStatus
    #endif // _WIN32
    {
        STOPPED = 0,
        STARTED = 1
    };

    /**
     * \~english @brief Interface class for DVS cameras
     * \~chinese @brief DVS相机的接口类
     * 
     */
    class DVSENSE_API DvsCamera
    {
     private:
         friend DvsCameraManager;

    public:
        /** 
         * \~english @brief Constructor
         * \~english @param cameraDesc camera description
         * \~chinese @brief 构造函数
         * \~chinese @param cameraDesc 相机描述
         */
        DvsCamera(CameraDescription cameraDesc);

        /** 
         * \~english @brief Check if the camera is connected
         * \~english @return true if connected, otherwise false
         * \~chinese @brief 检查相机是否连接
         * \~chinese @return 如果连接返回true，否则返回false
         */
        virtual const bool isConnected() = 0;

        /** 
         * \~english @brief Get camera description
         * \~english @return @ref CameraDescription 
         * \~chinese @brief 获取相机描述
         * \~chinese @return @ref CameraDescription  
         */
        const CameraDescription getDescription()
        {
            return cameraDesc_;
        }

        /** 
         * \~english @brief Add a callback function to handle events
         * \~english @param cb callback function
         * \~english @return callback id With id you can @ref removeEventsStreamHandleCallback
         * \~chinese @brief 添加一个回调函数来处理事件
         * \~chinese @param cb 回调函数
         * \~chinese @return 回调函数的id，通过id可以@ref removeEventsStreamHandleCallback
         */
        virtual uint32_t addEventsStreamHandleCallback(EventsStreamHandleCallback cb) = 0;

        /**
         * \~english @brief Remove a callback function by id
         * \~english @param callback_id 
         * \~english @return true if removed successfully
         * \~english @return false if there is no callback function with the corresponding id in the callback function list.
         * \~chinese @brief 通过id移除一个回调函数
         * \~chinese @param callback_id 回调函数的id
         * \~chinese @return 如果成功移除返回true
         * \~chinese @return 如果回调函数列表中没有对应id的回调函数，则返回false。
         */
        virtual bool removeEventsStreamHandleCallback(uint32_t callback_id) = 0;

        /**
         * \~english @brief Add a callback function to handle events
         * \~english @param cb callback function
         * \~english @return callback id With id you can @ref removeEventsStreamHandleCallback
         * \~chinese @brief 添加一个回调函数来处理事件
         * \~chinese @param cb 回调函数
         * \~chinese @return 回调函数的id，通过id可以@ref removeEventsStreamHandleCallback
         */
        virtual uint32_t addTriggerInCallback(DvsTriggerInCallback cb) = 0;

        /**
         * \~english @brief Remove a callback function by id
         * \~english @param callback_id
         * \~english @return true if removed successfully
         * \~english @return false if there is no callback function with the corresponding id in the callback function list.
         * \~chinese @brief 通过id移除一个回调函数
         * \~chinese @param callback_id 回调函数的id
         * \~chinese @return 如果成功移除返回true
         * \~chinese @return 如果回调函数列表中没有对应id的回调函数，则返回false。
         */
        virtual bool removeTriggerInCallback(uint32_t callback_id) = 0;

        /**
         * \~english @brief Get the next batch of events
         * Before using the getNextBatch function, 
         * you need to use @ref setBatchEventNum to set the number of events you need to fetch, 
         * or @ref setAccumulateEventsTime to set the interval at which you need to fetch the events
         * \~english @param event_batch 
         * \~english @return true if fetched successfully
         * \~english @return false if there is no event to fetch
         * \~chinese @brief 获取下一批事件
         * 在使用getNextBatch函数之前，您需要使用 @ref setBatchEventsNum 设置需要获取的事件数量，
         * 或者使用 @ref setBatchEventsTime 设置需要获取事件的时间间隔
         * \~chinese @param event_batch 事件批次
         * \~chinese @return 如果成功获取返回true
         * \~chinese @return 如果没有事件可以获取返回false
         */
        virtual bool getNextBatch(Event2DVector& event_batch) = 0;

        /**
         * \~english @brief Set the number of events to be fetched
         * \~english @param n number of events
         * \~chinese @brief 设置需要获取的事件数量
         * \~chinese @param n 事件数量
         */
        virtual void setBatchEventsNum(uint64_t n) = 0;

        /**
         * \~english @brief Set the time interval at which events are fetched
         * \~english @param n interval in microseconds
         * \~chinese @brief 设置获取事件的时间间隔
         * \~chinese @param n 时间间隔，单位为微秒
         */
        virtual void setBatchEventsTime(TimeStamp n) = 0;

        /**
         * \~english @brief Start the camera
         * \~english @return int 0 if success, otherwise return error code
         * \~chinese @brief 启动相机
         * \~chinese @return int 如果成功返回0，否则返回错误代码
         */
        virtual int start() = 0;

        /**
         * \~english @brief Stop the camera
         * \~english @return int 0 if success, otherwise return error code
         * \~chinese @brief 停止相机
         * \~chinese @return int 如果成功返回0，否则返回错误代码
         */
        virtual int stop() = 0;

        /**
         * \~english @brief Start recording events
         * \~english @param file_path 
         * \~english @return int 0 if success, otherwise return error code
         * \~chinese @brief 开始记录事件
         * \~chinese @param file_path
         * \~chinese @return int 如果成功返回0，否则返回错误代码
         */
        virtual int startRecording(std::string file_path) = 0;

        virtual void setFileCacheTime(uint16_t sec, std::string file_path = ".") {};

        /**
         * \~english @brief Stop recording events
         * \~english @return int 0 if success, otherwise return error code
         * \~chinese @brief 停止记录事件
         * \~chinese @return int 如果成功返回0，否则返回错误代码
         */
        virtual int stopRecording() = 0;

        /**
         * \~english @brief Get the Width of the camera sensor
         * \~english @return uint16_t
         * \~chinese @brief 获取相机传感器的宽度
         * \~chinese @return uint16_t
         */
        virtual uint16_t getWidth() = 0;

        /**
         * \~english @brief Get the Height of the camera sensor
         * \~english @return uint16_t
         * \~chinese @brief 获取相机传感器的高度
         * \~chinese @return uint16_t
         */
        virtual uint16_t getHeight() = 0;

        /**
         * \~english @brief set the callback function to get the statistic information
         * \~english @param cb callback function
         * \~chinese @brief 设置回调函数以获取统计信息
         * \~chinese @param cb 回调函数
         */
        virtual void setStatisticInfoCallback(DsStatisticInfoCallback cb) {};

        /**
         * \~english @brief Get all the tools information
         * \~english @return std::vector<ToolInfo> information of all tools
         * \~chinese @brief 获取所有工具的信息
         * \~chinese @return std::vector<ToolInfo> 相机中所有工具的信息
         */
        const std::vector<ToolInfo> getAllToolsInfo();

        /**
         * \~english @brief Get the tool information
         * \~english @param type tool type
         * \~english @return ToolInfo information of the tool
         * \~chinese @brief 获取工具信息
         * \~chinese @param type 工具类型
         * \~chinese @return ToolInfo 工具的信息
         */
		const ToolInfo getToolInfo(ToolType type);

        /**
         * \~english @brief Get the tool
         * \~english @param type tool type
         * \~english @return std::shared_ptr<CameraTool> tool
         * \~chinese @brief 获取工具
         * \~chinese @param type 工具类型
         * \~chinese @return std::shared_ptr<CameraTool> 工具
         */
        const std::shared_ptr<CameraTool> getTool(ToolType type);

    protected:
        /**
         * \~english @brief Get the camera description
         * \~english @return @ref CameraDescription
         * \~chinese @brief 获取相机描述
         * \~chinese @return @ref CameraDescription
         */
        CameraDescription cameraDesc_;

        /**
        * \~english @brief When a camera is opened, it should be initialized
        * \~english @return 0 if success, otherwise return error code
        * \~chinese @brief 打开相机时，应该初始化
        * \~chinese @return 如果成功返回0，否则返回错误代码
        */
        virtual int init() = 0;

        // tools
        std::map<ToolType, std::shared_ptr<CameraTool>> tools_;
    };

} // namespace dvsense            

#endif // DVSCAMERA_HPP
