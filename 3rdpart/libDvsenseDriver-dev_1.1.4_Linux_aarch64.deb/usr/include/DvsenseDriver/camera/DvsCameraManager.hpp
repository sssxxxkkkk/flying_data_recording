#pragma once
#include <vector>
#include <string>
#include <memory>
#include <map>
#include <stdexcept>
#include "DvsenseDriver/camera/DvsCamera.hpp"
#include "DvsenseDriver/camera/FusionCamera.hpp"
#include "DvsenseBase/Utils/FuncUtils.hpp"

#ifdef _WIN32
#ifdef DVSENSE_EXPORTS
    #define DVSENSE_API __declspec(dllexport)
    #else
    #define DVSENSE_API __declspec(dllimport)
    #endif
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense
{

    /**
     * @brief
     * \~english @brief Shared pointer to manage camera devices
     * \~chinese @brief 用于管理相机设备的共享指针
     */
    typedef DVSENSE_API std::shared_ptr<DvsCamera> CameraDevice;
    typedef DVSENSE_API std::shared_ptr<FusionCamera> FusionCameraDevice;

    /** \~english @brief Camera Manager class
     * \~chinese @brief 相机管理器类
     */
    class DVSENSE_API DvsCameraManager
    {
    public:
        /**
         * \~english @brief Constructor
         * \~chinese @brief 构造函数
         */
        DvsCameraManager();

        /** \~english @brief Update the current searchable camera list.
         * \~english @return int Returns the size of the list in the current camera.
         * \~chinese @brief 更新当前可搜索的相机列表。
         * \~chinese @return int 返回当前相机列表的大小。
         */
        int updateCameras();

        /** \~english @brief Get the Camera Descriptions vector
         * \~english @return const std::vector<CameraDescription> Returns the vector of camera descriptions.
         * \~chinese @brief 获取相机描述符向量
         * \~chinese @return const std::vector<CameraDescription> 返回相机描述符的常量引用。
         */
        std::vector<CameraDescription> getCameraDescs();

        /** \~english @brief Open a camera with the given serial number.
         * \~english @param serial Serial number of the camera to open.
         * \~english @return CameraDevice Pointer to the DvsCamera object.
         * \~chinese @brief 使用给定的序列号打开相机。
         * \~chinese @param serial 要打开的相机的序列号。
         * \~chinese @return CameraDevice 指向 DvsCamera 对象的智能指针。
         */
        CameraDevice openCamera(Serial serial);

        FusionCameraDevice openFusionCamera(Serial serial);

    private:
        /** \~english @brief Map storing connected camera devices.
         * \~chinese @brief 存储已连接相机设备的映射表
         */
        std::map<Serial, CameraDevice> cameraDevices_;
        std::map<Serial, FusionCameraDevice> fusion_camera_devices_;

        /** \~english @brief Remove unplugged cameras.
         * \~chinese @brief 移除已拔除的相机
         */
        void removeUnpluggedCameras();

        /** \~english @brief Find and record all connected cameras.
         * \~english @return size_t Returns the number of found cameras.
         * \~chinese @brief 查找并记录所有连接的相机
         * \~chinese @return size_t 返回找到的相机数量
         */
        size_t findCameras();

        /** \~english @brief Find and record all connected cameras of a specific type.
         * \~english @param cameraType Type of the camera.
         * \~english @return size_t Returns the number of found cameras.
         * \~chinese @brief 根据相机类型查找并记录所有连接的相机
         * \~chinese @param cameraType 相机类型
         * \~chinese @return size_t 返回找到的相机数量
         */
        size_t findCameras(CAMERA_TYPE cameraType);

        /** \~english @brief Template function to find and record all connected cameras of a specific type.
         * \~chinese @brief 模板函数，用于查找并记录所有连接的指定类型的相机
         */
        template <class cameraClass>
        size_t findCameras();

        template <class cameraClass>
        size_t findFusionCameras();
    };

} // namespace dvsense