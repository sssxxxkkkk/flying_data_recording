#ifndef DVS_CAMERA_UTILS_HPP
#define DVS_CAMERA_UTILS_HPP

#include <string>
#include "DvsenseBase/Utils/TypeUtils.hpp"

#ifdef _WIN32
	#ifdef DVSENSE_HAL_EXPORTS
		#define DVSENSE_API __declspec(dllexport)
	#else
		#define DVSENSE_API __declspec(dllimport)
	#endif
#else
#define DVSENSE_API
#endif // _WIN32

namespace dvsense
{
    // ------- Hide from doxygen -------
    /** \cond */

    enum INTERFACE_TYPE
    {
        USB
    };

    DVSENSE_API std::string to_string(INTERFACE_TYPE interface_type);

    enum CAMERA_TYPE
    {
        EVK4, 
        DvsLume,
        DVSync
    };
    /** \endcond */
    // ------- Hide from doxygen end -------

    enum STREAM_TYPE
    {
        DVS_STREAM, 
        APS_STREAM, 
        FUSION_STREAM
    };
    
    /**
     * \~english @brief Condition to cut the batch of events, n_events or n_us
     * \~chinese @brief 事件批次的切割条件，n个事件(N_EVENTS) 或 固定事件(N_US)
     */
    #ifdef _WIN32
    enum DVSENSE_API BatchConditionType
    #else
    enum BatchConditionType
    #endif // _WIN32
    {
        NO_CONDITION = 0,
        N_EVENTS,
        N_US
    };

    using Serial = std::string;

    /**
     * \~english @brief A struct to describe the camera information
     * \~chinese @brief 用于描述相机信息的结构体 
     */
    // TODO: Make Description class abstract according to interfaces
    struct DVSENSE_API CameraDescription
    {
        Serial serial;
        std::string product;
        std::string manufacturer;
        uint16_t vid;
        uint16_t pid;
        enum INTERFACE_TYPE interfaceType;
    };

} // namespace dvsense

#endif // DVS_CAMERA_UTILS_HPP
