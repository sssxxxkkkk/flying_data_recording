#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "DvsenseDriver::Base" for configuration "Release"
set_property(TARGET DvsenseDriver::Base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(DvsenseDriver::Base PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "spdlog::spdlog"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libDvsenseBase.so.1.1.4"
  IMPORTED_SONAME_RELEASE "libDvsenseBase.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS DvsenseDriver::Base )
list(APPEND _IMPORT_CHECK_FILES_FOR_DvsenseDriver::Base "${_IMPORT_PREFIX}/lib/libDvsenseBase.so.1.1.4" )

# Import target "DvsenseDriver::Hal" for configuration "Release"
set_property(TARGET DvsenseDriver::Hal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(DvsenseDriver::Hal PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libDvsenseHal.so.1.1.4"
  IMPORTED_SONAME_RELEASE "libDvsenseHal.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS DvsenseDriver::Hal )
list(APPEND _IMPORT_CHECK_FILES_FOR_DvsenseDriver::Hal "${_IMPORT_PREFIX}/lib/libDvsenseHal.so.1.1.4" )

# Import target "DvsenseDriver::Driver" for configuration "Release"
set_property(TARGET DvsenseDriver::Driver APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(DvsenseDriver::Driver PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libDvsenseDriver.so.1.1.4"
  IMPORTED_SONAME_RELEASE "libDvsenseDriver.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS DvsenseDriver::Driver )
list(APPEND _IMPORT_CHECK_FILES_FOR_DvsenseDriver::Driver "${_IMPORT_PREFIX}/lib/libDvsenseDriver.so.1.1.4" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
